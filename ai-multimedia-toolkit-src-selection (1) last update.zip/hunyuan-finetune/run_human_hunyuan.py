import argparse, json, time, os
import torch
from PIL import Image

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True)
    ap.add_argument("--prompt", default="a person standing, gentle idle motion, breathing, blinking, hair swaying")
    ap.add_argument("--negative", default="worst quality, inconsistent motion, blurry, deformed body, extra limbs, static")
    ap.add_argument("--model", default="hunyuanvideo-community/HunyuanVideo-I2V")
    ap.add_argument("--steps", type=int, default=30)
    ap.add_argument("--frames", type=int, default=49)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--width", type=int, default=720)
    ap.add_argument("--height", type=int, default=1280)
    ap.add_argument("--cpu", action="store_true")
    ap.add_argument("--out", default="out/hunyuan_clip.mp4")
    a = ap.parse_args()
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    use_cpu = a.cpu or not torch.cuda.is_available()
    if use_cpu:
        print("CPU mode with 13B is not realistic (many hours). Use a 24GB+ GPU.")
    from diffusers import HunyuanVideoImageToVideoPipeline as P
    t0 = time.time()
    img = Image.open(a.image).convert("RGB").resize((a.width - a.width % 16, a.height - a.height % 16))
    pipe = P.from_pretrained(a.model, torch_dtype=torch.float32 if use_cpu else torch.bfloat16)
    if use_cpu:
        try: pipe.enable_sequential_cpu_offload()
        except Exception: pass
    else:
        pipe = pipe.to("cuda")
        try: pipe.enable_model_cpu_offload()
        except Exception: pass
    t1 = time.time()
    g = torch.Generator().manual_seed(a.seed)
    t2 = time.time()
    out = pipe(image=img, prompt=a.prompt, negative_prompt=a.negative,
               num_frames=a.frames, num_inference_steps=a.steps,
               guidance_scale=6.0, generator=g)
    t3 = time.time()
    frames = out.frames[0]
    import imageio
    imageio.mimsave(a.out, frames, fps=24)
    info = {
        "model": a.model, "steps": a.steps, "frames": len(frames),
        "load_sec": round(t1 - t0, 1), "infer_sec": round(t3 - t2, 1),
        "total_sec": round(t3 - t0, 1),
        "cuda": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu",
    }
    open(os.path.join(os.path.dirname(a.out), "timing.json"), "w").write(json.dumps(info, indent=2))
    print(json.dumps(info, indent=2))

if __name__ == "__main__":
    main()
