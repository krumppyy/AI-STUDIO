import argparse, json, time, os
import torch
from PIL import Image

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True)
    ap.add_argument("--prompt", default="same person, warm cinematic light, photorealistic")
    ap.add_argument("--negative", default="worst quality, blurry, deformed body, extra limbs, watermark, text")
    ap.add_argument("--model", default="Qwen/Qwen-Image-Edit")
    ap.add_argument("--steps", type=int, default=30)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--cpu", action="store_true")
    ap.add_argument("--out", default="out/qwen_edit.png")
    a = ap.parse_args()
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    use_cpu = a.cpu or not torch.cuda.is_available()
    from diffusers import QwenImageEditPipeline as P
    t0 = time.time()
    img = Image.open(a.image).convert("RGB")
    pipe = P.from_pretrained(a.model, torch_dtype=torch.float32 if use_cpu else torch.bfloat16)
    if use_cpu:
        try: pipe.enable_sequential_cpu_offload()
        except Exception: pass
        print("CPU mode: 20B edit takes a long time. Prefer GPU.")
    else:
        pipe = pipe.to("cuda")
        try: pipe.enable_model_cpu_offload()
        except Exception: pass
    t1 = time.time()
    g = torch.Generator().manual_seed(a.seed)
    t2 = time.time()
    out = pipe(image=img, prompt=a.prompt, negative_prompt=a.negative,
               num_inference_steps=a.steps, generator=g)
    t3 = time.time()
    out.images[0].save(a.out)
    info = {
        "model": a.model, "steps": a.steps,
        "load_sec": round(t1 - t0, 1), "infer_sec": round(t3 - t2, 1),
        "total_sec": round(t3 - t0, 1),
        "cuda": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu",
    }
    open(os.path.join(os.path.dirname(a.out), "timing.json"), "w").write(json.dumps(info, indent=2))
    print(json.dumps(info, indent=2))

if __name__ == "__main__":
    main()
