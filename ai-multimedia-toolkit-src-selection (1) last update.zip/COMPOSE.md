# Composite studio (`src/compose.js`)

Cut out subject → transparent PNG → generate new scene → blend with
photographic toolkit (burn, dodge, sharpen, grain, shadow, light-wrap).

## Trained behavior (measured on 1_Final.jpg)

- **Cutout**: MediaPipe selfie segmenter, mask-space polarity self-check
  (raw>0 is background for this model — learned the hard way), feathered
  `destination-in`. Never hand-edit alpha pixels (kills RGB).
- **Exposure**: gain-based (blacks preserved) + 15% chroma drift + capped
  dodge/burn. Full mean-shift turns her green in parks — never again.
- **Auto ratio/placement**: fit width, thirds-side with calmer background,
  bust-crop detection (bottom-row opacity) for grounding.
- **Shadow**: brightest-cell light estimate, offset opposite, opacity from
  scene contrast, softer for bust crops.
- **Wrap**: rim-only (eroded mask), never a full veil (ghosts the body).
- **Scene guard**: skin pre-check + segmenter person check, 3 attempts.
