import argparse, json, time, os
import torch
from PIL import Image

def load_pipe(model, dtype):
    try:
        from diffusers import LTXImageToVideoPipeline as P
        return P.from_pretrained(model, torch_dtype=dtype), "ltx-i2v"
    except Exception:
        from diffusers import DiffusionPipeline as P
        return P.from_pretrained(model, torch_dtype=dtype), "generic"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True)
    ap.add_argument("--prompt", default="a person standing, gentle idle motion, breathing, blinking, hair swaying")
    ap.add_argument("--negative", default="worst quality, inconsistent motion, blurry, deformed body, extra limbs, static")
    ap.add_argument("--model", default="Lightricks/LTX-Video")
    ap.add_argument("--steps", type=int, default=30)
    ap.add_argument("--frames", type=int, default=49)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--width", type=int, default=768)
    ap.add_argument("--height", type=int, default=512)
    ap.add_argument("--out", default="out/ltx_clip.mp4")
    ap.add_argument("--cpu", action="store_true", help="CPU-only: float32, sequential offload, VAE tiling+slicing")
    ap.add_argument("--compile", action="store_true", help="torch.compile (inductor) the transformer: ~1.2-2x faster, slow first run")
    a = ap.parse_args()
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    t0 = time.time()
    img = Image.open(a.image).convert("RGB").resize((a.width, a.height))
    use_cpu = a.cpu or not torch.cuda.is_available()
    dt = torch.float32 if use_cpu else torch.float16
    pipe, kind = load_pipe(a.model, dt)
    if use_cpu:
        try: pipe.enable_sequential_cpu_offload()
        except Exception: pass
        try: pipe.vae.enable_tiling(); pipe.vae.enable_slicing()
        except Exception: pass
        print("CPU mode: expect ~30-90+ min for 25 frames distilled; full 49f base can take hours.")
    elif torch.cuda.is_available():
        pipe = pipe.to("cuda")
        try: pipe.enable_model_cpu_offload()
        except Exception: pass
    if a.compile:
        try:
            pipe.transformer.compile(mode="reduce-overhead")
            print("torch.compile on: first run compiles (slow), later steps ~1.2-2x faster.")
        except Exception as e:
            print("torch.compile off:", e)
    t1 = time.time()
    g = torch.Generator().manual_seed(a.seed)
    t2 = time.time()
    kw = dict(image=img, prompt=a.prompt, num_frames=a.frames, num_inference_steps=a.steps, generator=g)
    try:
        out = pipe(**kw, negative_prompt=a.negative, height=a.height, width=a.width)
    except TypeError:
        out = pipe(**kw)
    t3 = time.time()
    frames = out.frames[0]
    import imageio
    imageio.mimsave(a.out, frames, fps=24)
    info = {
        "model": a.model, "pipe": kind, "steps": a.steps, "frames": len(frames),
        "load_sec": round(t1 - t0, 1), "infer_sec": round(t3 - t2, 1),
        "total_sec": round(t3 - t0, 1),
        "cuda": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu",
    }
    open(os.path.join(os.path.dirname(a.out), "timing.json"), "w").write(json.dumps(info, indent=2))
    print(json.dumps(info, indent=2))

if __name__ == "__main__":
    main()
