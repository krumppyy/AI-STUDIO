# AIVideoGen Server

Your own video-generation backend. It runs open-source image-to-video models on **your** GPU and
exposes a tiny HTTP + SSE API that the AI Video Gen web app talks to directly — no Hugging Face
account, no API token, no third-party relay, no quota imposed by anyone else.

```
python server.py                          # http://127.0.0.1:7860
python server.py --tunnel cloudflare       # + a public https URL (no account needed)
python server.py --model wan5b --preload   # load a model up front
python server.py --key my-secret           # require a shared key on every /api/ call
python server.py --list                    # print the model catalogue
python server.py --download wan5b          # fetch a model's weights, then exit
python server.py --weights                 # what is already on disk, and where
```

Once a model's weights have been downloaded they live on disk, so the server — and the app — keep
working with the internet unplugged. Nothing is sent anywhere except the one clip you ask for.

---

## Quick start (your own machine)

```bash
# 1. Python 3.10+ and a GPU driver (CUDA or Apple-silicon)
cd src/server
pip install -r requirements.txt

# CUDA builds of PyTorch (pick the right one for your driver):
pip install torch --index-url https://download.pytorch.org/whl/cu124

# 2. Run it
python server.py --preload

# 3. In the web app: Settings → Where the rendering happens → My GPU server address
#    →  http://127.0.0.1:7860   → press Test
```

`http://127.0.0.1` and `http://localhost` are treated as *potentially trustworthy* origins by
Chrome, Edge and Firefox, so an https page (like the generator) is allowed to call them.
Safari blocks that mixed content — use the tunnel flag there.

### Sharing it

```bash
python server.py --tunnel cloudflare        # prints https://xxxx.trycloudflare.com
python server.py --tunnel cloudflare --key my-secret   # same, but gated
```

The tunnel is a Cloudflare *quick tunnel*: no account, no signup, expires when the process stops.
Anyone with the URL can use the GPU, so pass `--key` when the address leaves your machine. The
`--key` value must also be pasted into the app's **Server key** field (stored locally, sent as the
`X-API-Key` header or a `?key=` query parameter).

### Models

| id | model | in → out | one shot | VRAM | download | ModelScope id |
| --- | --- | --- | --- | --- | --- | --- |
| `wan22a14b` | Wan 2.2 I2V A14B + Lightning LoRA | image → video | 16 fps · ≤5 s @ 720p | ~30 GB | 127 GB | `Wan-AI/Wan2.2-I2V-A14B-Diffusers` |
| `wan22_t2v_a14b` | Wan 2.2 T2V A14B + Lightning LoRA | text → video | 16 fps · ≤5 s @ 720p | ~30 GB | 127 GB | `Wan-AI/Wan2.2-T2V-A14B-Diffusers` |
| `wan21_720p` | Wan 2.1 I2V 14B 720p | image → video | 16 fps · ≤5 s @ 720p | ~28 GB | 90 GB | `Wan-AI/Wan2.1-I2V-14B-720P-Diffusers` |
| `wan21_480p` | Wan 2.1 I2V 14B 480p | image → video | 16 fps · ≤5 s @ 480p | ~28 GB | 90 GB | `Wan-AI/Wan2.1-I2V-14B-480P-Diffusers` |
| `wan21_flf2v` | Wan 2.1 FLF2V 14B 720p | first+last frame → video | 16 fps · 2–5 s @ 720p | ~28 GB | 90 GB | `Wan-AI/Wan2.1-FLF2V-14B-720P-diffusers` |
| `wan21_t2v14b` | Wan 2.1 T2V 14B | text → video | 16 fps · ≤5 s | ~28 GB | 81 GB | `Wan-AI/Wan2.1-T2V-14B-Diffusers` |
| `wan5b` | Wan 2.2 TI2V 5B | image/text → video | 24 fps · ≤5 s | ~14 GB | 35 GB | `Wan-AI/Wan2.2-TI2V-5B-Diffusers` |
| `wan13b` | Wan 2.1 T2V 1.3B | text → video | 16 fps · ≤5 s | ~8 GB | 29 GB | `Wan-AI/Wan2.1-T2V-1.3B-Diffusers` |
| `hunyuan_t2v` | HunyuanVideo T2V 13B | text → video | 24 fps · ≤5 s | ~45 GB | 26 GB | — (Hugging Face only) |
| `hunyuan_i2v` | HunyuanVideo I2V 13B | image → video | 24 fps · ≤5 s | ~45 GB | 30 GB | — (Hugging Face only) |
| `cogvideox` | CogVideoX 1.5 5B I2V | image → video | 16 fps · 5 s | ~20 GB | 31 GB | — (Hugging Face only) |
| `cogvideox5b_i2v` | CogVideoX 5B I2V | image → video | 8 fps · 5 s | ~18 GB | 22 GB | `AI-ModelScope/CogVideoX-5b-I2V` |
| `cogvideox5b` | CogVideoX 5B | text → video | 8 fps · 6 s | ~14 GB | 22 GB | `AI-ModelScope/CogVideoX-5b` |
| `cogvideox2b` | CogVideoX 2B | text → video | 8 fps · 6 s | ~9 GB | 14 GB | `AI-ModelScope/CogVideoX-2b` |
| `i2vgenxl` | I2VGen-XL | image → video | 8 fps · 2 s | ~12 GB | 18 GB | `AI-ModelScope/i2vgen-xl` |
| `ltx` | LTX Video 2B | image/text → video | 24 fps · ≤5 s | ~12 GB | 12 GB | `Lightricks/LTX-Video` |
| `svd` | Stable Video Diffusion XT | image → video | 7 fps · 4 s | ~9 GB | 33 GB | `AI-ModelScope/stable-video-diffusion-img2vid-xt` |
| `zeroscope` | Zeroscope v2 576w | text → video | 8 fps · 3 s | ~4 GB | 4 GB | — (Hugging Face only) |

More models = one more row in the `MODELS` list at the top of `server.py`; any diffusers
image-to-video pipeline works. `--list` prints the current catalogue.

The two **HunyuanVideo** entries are the heaviest here and the ones to treat with the most care.
Their argument contract was verified against the diffusers pipeline source (frames must be `4n+1`,
which the frame maths already produces; `guidance_scale` is the *embedded* guidance of a
CFG-distilled model and 6.0 is the pipeline's own example value; the LLaVA prompt template is the
pipeline's default, so nothing is threaded through; height/width must be divisible by 16, which
`call_kwargs()` enforces). What has **not** been verified is a real render on a GPU — the first run
is the test. Tencent's newer **HunyuanVideo 1.5** (~8B, distilled, 6 steps at guidance 1) has no
diffusers pipeline yet (`tencent/HunyuanVideo-1.5` ships its own repo, `library_name:
"HunyuanVideo-1.5"`), so this app reaches it through the free HunyuanVideo 1.5 Space instead — see
the `hunyuan15` entry in `src/providers.js`.

Two entries carry a **Lightning LoRA** (a 1.4 GB distillation adapter from `lightx2v/Wan2.2-Distill-Loras`)
that is downloaded and attached automatically, turning a 30-step 14B run into a 4-step one at the same
quality. `--no-lora` turns it off.

### LoRA adapters

`LORAS` at the top of `server.py` is the adapter catalogue. The distillation ones are attached to the
models that name them; these four are selectable:

| id | what it does | size | source |
| --- | --- | --- | --- |
| `distill` | the 4-step Lightning distillation, attached automatically | 1.4 GB | `lightx2v/Wan2.2-Distill-Loras` |
| `nsfw` | explicit adult content — a base Wan checkpoint has never seen any, and a prompt alone will not conjure it | 1.6 GB | `lopi999/Wan2.2-I2V_General-NSFW-Lora` |
| `nsfw_anatomy` | close-shot anatomy detail, pairs with the general one | 0.5 GB | `JERRYNPC/WAN2.2-LORA-NSFW` |
| `motion` | more body movement — aimed at the "nothing in the shot moves" failure | 1.2 GB | `rzgar/Wan2.2-Bernini-R-Motion-Enhancer-n4w-i2v` |

Three ways to ask for them, all equivalent:

```bash
python server.py --lora nsfw,motion          # every job on this server
```
```jsonc
// a single request
POST /api/generate {"model": "wan22a14b", "loras": ["nsfw", "motion"], ...}
POST /api/generate {"model": "wan22a14b", "lora": "nsfw", ...}      // one id
POST /api/generate {"model": "wan22a14b", "lora": "none", ...}      // bare checkpoint
POST /api/generate {"model": "wan22a14b", "loras": ["myorg/mylora:file.safetensors"]}
```
The web app sends `["nsfw", "motion"]` by itself when its NSFW switch is on and the model is a Wan.
Nothing is fetched until it is actually selected, and an adapter that cannot be downloaded or attached
is skipped with a warning — the job runs the base model rather than failing.

**The two-expert rule.** Wan 2.2 A14B is high-noise and low-noise experts in one checkpoint, and its
LoRAs ship as a matching pair. Each half is attached to *its own* transformer; attaching both to one,
or a half to the wrong one, is worse than attaching nothing. The suffix decides (`...high_noise...` /
`...low_noise...`, `NSFW-22-H-` / `NSFW-22-L-`), and a single-file adapter goes to the high-noise side.
Each file is loaded under its own adapter name and then all of them are armed together, so stacked
adapters sum rather than replace one another.

### Precision

`--precision auto|fp32|fp16|bf16|fp8` (or the older `--dtype`) chooses the weight dtype. `auto` is
bfloat16 on Ampere and newer, float16 on older CUDA, and float32 on CPU. `fp8` uses `float8_e4m3fn`
and needs Ada/Hopper — asked for on an older card it degrades to bf16 rather than failing mid-render,
because a 20-minute job that dies at step 3 is worse than one that started in a precision it can
actually compute. The chosen precision is reported by `/api/health` and in every job's meta.

`enable_model_cpu_offload()` is used automatically when the card has less VRAM than the model wants.

### Frame rate

A model renders at one rate — Wan at 16 fps, LTX at 24 — and asking it for more only produces more
frames of the same motion (and an OOM). So a request for a **higher** rate renders at the model's own
rate and is interpolated up afterwards with ffmpeg's `minterpolate` (motion-compensated, so 60 fps is
60 real frames rather than a 16 fps file with a 60 on the label). A request for a **lower** rate simply
renders fewer frames. `"interpolate": false` keeps the delivered file at the render rate. The job meta
says which happened: `fps`, `interpolated`, `precision`, `loras`.

`native` in the catalogue is the long side a model was trained at: a request below it is scaled **up**
to it, because feeding a 720p model a 480p frame is how you get mush. Send `{"native": false}` to
override that and render at exactly the size you asked for.

## Weights — where the models come from

Nothing needs an account, a token or a mirror. The server fetches a model's files the first time
that model is used and keeps them on disk, so after that first run it works with the internet
unplugged. Both download SDKs **resume** an interrupted transfer, so a dropped connection costs
nothing.

Three sources are tried in order:

1. **ModelScope** (`--source ms`, and the first attempt under the default `--source auto`). Its copy
   of the whole Wan family — 2.1 and 2.2, 5B and 14B, image-to-video, text-to-video and
   first/last-frame — is complete, it needs no mirror, and it is usually far quicker than
   huggingface.co outside the US and EU, and reachable in places where huggingface.co is not.
2. **Hugging Face** (`--source hf`, and the second attempt under `auto`).
3. **The mirror** named by `--hf-endpoint` (`https://hf-mirror.com` is tried last under `auto`, and
   is what to reach for when huggingface.co refuses to resolve).

```bash
pip install modelscope                      # the ModelScope SDK (already in requirements.txt)
python server.py --download wan5b           # fetch one model's files, then exit
python server.py --download wan22a14b,wan5b # several at once
python server.py --download all             # the whole catalogue — ~800 GB, think first
python server.py --weights                  # what is on disk, where, and how big
python server.py --source hf --hf-endpoint https://hf-mirror.com   # force the mirror
python server.py --offline                  # never download: fail if the weights are not cached
```

Every generation reports download progress over the same SSE stream it uses for denoising steps, so
the app shows a real progress bar (and a byte count) on a model's first run.

Cache: `~/.cache/aivideogen/models/<owner>--<name>`, with a `weights.json` index beside it
(`--cache` / `--models-dir` to move it). Deleting a model's folder, or `POST /api/weights/remove`,
gets the disk space back.

### Fetching by hand

Optional — the server does all of this itself — but useful for pre-seeding a machine, or if you
would rather drive the CLI. These are ModelScope's own instructions:

```bash
# install the SDK first
pip install modelscope

# command line: download the full model repo
modelscope download --model Wan-AI/Wan2.1-T2V-14B

# command line: a single file into a chosen folder
modelscope download --model Wan-AI/Wan2.1-T2V-14B README.md --local_dir ./dir

# python SDK
from modelscope import snapshot_download
model_dir = snapshot_download('Wan-AI/Wan2.1-T2V-14B')

# git (git-lfs must be installed)
git lfs install
git clone https://www.modelscope.cn/Wan-AI/Wan2.1-T2V-14B.git
GIT_LFS_SKIP_SMUDGE=1 git clone https://www.modelscope.cn/Wan-AI/Wan2.1-T2V-14B.git
```

For the CLI's extended options see the ModelScope documentation.

Use the **`…-Diffusers`** repos — those are the ones `diffusers` can load, and each is ~90–127 GB.
The native releases (`Wan-AI/Wan2.1-I2V-14B-720P`, `Wan-AI/Wan2.1-T2V-14B`, …) hold the same
weights in the original non-diffusers layout, so they are only worth having for ComfyUI.

To use a folder you fetched yourself, either drop it where the cache expects it
(`~/.cache/aivideogen/models/Wan-AI--Wan2.1-I2V-14B-720P-Diffusers`) or just let the server fetch it
— same files, same place, with progress.

### Sizes, and what to expect

| | download | runs on |
| --- | --- | --- |
| `zeroscope`, `cogvideox2b` | ~4–14 GB | anything, including CPU |
| `ltx`, `wan13b`, `svd`, `i2vgenxl`, `wan5b` | ~12–35 GB | a free Colab T4 (15 GB of VRAM, with CPU offload) |
| `wan21_480p`, `wan21_720p`, `wan21_t2v14b`, `wan22a14b` | 81–127 GB | 24 GB+ of VRAM, and patience |

Disk and patience are the real costs. `wan5b` is the sweet spot on a free GPU; the 14B models are
what the quality setting is for, when the machine can take it. Run `python server.py --list` for the
exact catalogue, and `--weights` to see what is already there.

## Free GPU hosts

The same `server.py` runs unchanged on all of these.

| Host | What you get free | How to run it |
| --- | --- | --- |
| **Google Colab** | T4 15 GB, sessions capped (~3-4 h of use, then it idles out) | open `../colab/AIVideoGen_Colab.ipynb`, sign in with Google, set the runtime to T4 GPU, Run all, paste the printed URL into the app |
| **Kaggle** | ~30 GPU-hours/week, T4 x2 or P100 | new Notebook → Settings → Accelerator: GPU T4 x2, Internet: On → `!pip install -r requirements.txt` → `!python server.py --tunnel cloudflare` in a cell (add `&` and tail the log to keep the cell responsive) |
| **SageMaker Studio Lab** | free account (approval may take a day), persistent home dir | open a terminal in a GPU runtime, install, `python server.py --tunnel cloudflare` |
| **Lightning AI Studio** | monthly free GPU credits, VS Code in the browser | open a terminal, `pip install -r requirements.txt`, `python server.py --tunnel cloudflare`, expose port if you want the direct URL |
| **Modal / RunPod / Vast.ai** | free signup credits, then cheap hourly GPUs | deploy this folder as a small container/web endpoint; the API is plain HTTP |
| **Your own box** | unlimited, offline | `python server.py` (see above) |

Colab is the easiest and is what the app's help dialog walks through. The catch is that free
Colab sessions end and the tunnel address changes, so the app is built to survive that: set
**Compute mode → Auto** and it falls back to the free public pool, then to the on-device rig,
so a dead server never leaves you with nothing.

## API

```
GET  /api/health                → {ok, device, gpu, vramGb, models:[…], busy, loaded,
                                   cached:[ids], lora, loraActive, loras:[…], precision,
                                   modelscope, weightsRoot, source}
GET  /api/models                → the catalogue
GET  /api/weights               → the weights cache: what is on disk, its source and size
POST /api/weights/download {model}                     → fetch a model's weights upfront
POST /api/weights/remove   {model, confirm:"remove"}   → delete them again
GET  /api/log                   → the last 120 server log lines
POST /api/load   {model}        → warm a model (downloads weights on first use)
POST /api/generate {model, prompt, negative, image, lastImage, width, height,
                    duration, fps, seed, steps, guidance, motion, nsfw, native,
                    lora, loras, interpolate}            → {job}
GET  /api/status/{job}          → Server-Sent Events, event: state  (state/progress/message/seed…)
GET  /api/result/{job}          → the finished mp4 bytes
POST /api/cancel/{job}          → stop a queued or running job
POST /api/relay {url, method?, headers?, body?, bodyB64?, contentType?}
                                → forward one request from this machine's address
GET  /api/relay/raw?url=…       → stream one GET straight back (binary + SSE safe)
GET  /                          → a plain status page you can open in a browser
```

When a job finishes, its meta (flattened onto the SSE snapshot) carries `model`, `modelLabel`,
`width`, `height`, `frames`, `fps`, `interpolated`, `duration`, `seed`, `renderSecs`, `steps`,
`guidance`, `precision`, `loras` and `lora` — so the app can say what actually ran.

`image` is a base64 `data:` URL (`data:image/jpeg;base64,…`), and `lastImage` is the optional
end frame for `wan21_flf2v`. Jobs run one at a time on a single worker thread; `POST /api/generate`
answers `409 busy` while another job is running — downloading weights counts as busy, because it is
the same queue (and reports progress on the same SSE stream).

### `/api/relay` — the server is also an address

The app can route its *Hugging Face Space* calls through this server when it is reachable, which
means those calls leave the internet from **your server's IP** instead of the visitor's browser.
That is the whole point of the app's "Privacy & IP rotation" settings:

- zero browser CORS and zero browser-side rate limiting — the request happens machine-to-machine;
- each generation can be sent via a different address (your server, a Cloudflare Worker, the
  built-in Perchance proxy, or a direct connection), so no single address accumulates the free
  ZeroGPU allowance;
- `credentials` never leave the browser, and no `Referer`/cookies are attached by the server.

It is deliberately **not an open proxy**: only these hosts are forwarded, and the response is
capped at 16 MB with a 180 s timeout.

```
huggingface.co  *.hf.space  *.hf.co  pollinations.ai
ipify.org  ifconfig.me  cloudflare.com
replicate.com  replicate.delivery  fal.run  fal.media  runwayml.com
```

(The last three groups are there because in private mode the app relays the paid vendors' APIs and
status polls too, and their clips are downloaded through the same relay.)

`POST /api/relay` body:

```json
{"url": "https://user-space.hf.space/gradio_api/call/generate_video",
 "method": "POST",
 "headers": {"content-type": "application/json"},
 "body": "{\"data\": [...]}"}
```

A multipart upload cannot travel as JSON text, so it is re-encoded and arrives as
`{"url": …, "method": "POST", "bodyB64": "…", "contentType": "multipart/form-data; boundary=…"}`.
The server decodes it and re-sends those exact bytes under that exact `content-type`, because a
browser picks a fresh random boundary every time it encodes a `FormData` — the bytes and the boundary
have to come from the same serialisation or the Space sees a body it cannot parse.

Response: `{ok: true, status, headers, body}` where `body` is the upstream response text (utf-8, invalid
bytes replaced). A non-2xx upstream is still `ok: true` (the status is forwarded); only an unreachable
host is `ok: false` with 502.

### `/api/relay/raw` — the two requests that are not small

`POST /api/relay` reads the whole answer into JSON, which is fine for a small reply but destroys a video
file and stalls a live progress stream. So `GET /api/relay/raw?url=…` hands the bytes back as they arrive,
with the upstream `content-type` intact — which is exactly what makes a Server-Sent Events response keep
flowing. Same host allow-list, same `--key` gate, wraps the same generator.

Nothing has to be enabled for this — the same process that renders your videos serves relays.
A `--key` on the server applies to `/api/relay` too, so a shared tunnel can't be abused.

## Security

`server.py` is public source — the browser app ships it. Never put a password, token or private
key in it. `--key` is a *shared* secret that is typed at runtime and compared on each request; it
is not compiled in. Only expose the tunnel when you are happy for that address to be used.

## Files

- `server.py` — the whole server (argparse → model registry → engine → HTTP API → `/api/relay` → tunnel)
- `requirements.txt` — pip dependencies
- `../colab/AIVideoGen_Colab.ipynb` — one-click Colab notebook

## Frozen copies (used by the Colab notebook)

The notebook can't read this folder, so cells 2 and 3 download frozen copies (and cell 5b can then run `server.py --download` to fetch the weights). After editing
`server.py` or `requirements.txt`, re-upload them (`upload_file`) and paste the new URLs into
the two `*_URL` variables in `../colab/AIVideoGen_Colab.ipynb`:

| File | URL |
| --- | --- |
| `server.py` | `https://user.uploads.dev/file/237197ec9cca4f194c7aa2bf781068ce.bin` |
| `requirements.txt` | `https://user.uploads.dev/file/f790e37fb50750db8d56c7598cfc6a7a.txt` |
