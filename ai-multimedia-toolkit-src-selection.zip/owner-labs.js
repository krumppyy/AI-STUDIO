const $ = (id) => document.getElementById(id);
const LS_PIN = "amt_owner_pin";
const SS_UNLOCK = "amt_labs_unlocked";

export const LOCKED_LABS = ["pageEditor", "pageCodecLab", "pageAIModelLab", "pageDevInsight"];

export function labsUnlocked() {
  try { return sessionStorage.getItem(SS_UNLOCK) === "1"; } catch { return false; }
}

let pendingPage = null;
let fails = 0;
let lockedUntil = 0;

function b64(u8) {
  let s = "";
  for (let i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i]);
  return btoa(s);
}

function unb64(str) {
  const bin = atob(String(str || ""));
  const u8 = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return u8;
}

async function sha256Hex(text) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function newSalt() {
  return b64(crypto.getRandomValues(new Uint8Array(16)));
}

async function hashPin(pin, salt) {
  return sha256Hex(salt + ":" + pin);
}

function isHashFormat(v) {
  return typeof v === "string" && /^v1:[A-Za-z0-9+/=]{20,60}:[a-f0-9]{64}$/.test(v);
}

function safeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string" || a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}

async function verifyPin(pin, saved) {
  if (!saved) return false;
  if (isHashFormat(saved)) {
    const [, salt, hash] = saved.split(":");
    return safeEqual(await hashPin(pin, salt), hash);
  }
  const ok = pin === saved;
  if (ok) {
    try {
      const salt = newSalt();
      localStorage.setItem(LS_PIN, `v1:${salt}:${await hashPin(pin, salt)}`);
    } catch {}
  }
  return ok;
}

async function storePin(pin) {
  const salt = newSalt();
  try {
    localStorage.setItem(LS_PIN, `v1:${salt}:${await hashPin(pin, salt)}`);
  } catch {}
}

function toast(msg) {
  if (window.toast) { window.toast(msg); return; }
  const host = document.querySelector(".toasts") || document.body;
  const t = document.createElement("div");
  t.className = "toast";
  t.textContent = msg;
  host.appendChild(t);
  setTimeout(() => t.remove(), 3200);
}

export function guardLabPage(pageId) {
  if (!LOCKED_LABS.includes(pageId)) return true;
  if (labsUnlocked()) return true;
  markTabs();
  pendingPage = pageId;
  const dlg = $("labLockGate");
  if (!dlg || !dlg.showModal) { toast("This lab is owner-only."); return false; }
  let has = false;
  try { has = !!localStorage.getItem(LS_PIN); } catch {}
  $("labLockTitle").textContent = has ? "Owner-only lab" : "Create owner PIN";
  $("labLockMsg").textContent = has
    ? "Editor, Codec Lab, Testing, AI Model Lab and Dev Insight are private while they are being built. Enter the owner PIN."
    : "First time: set the owner PIN you share with your co-builder. It lives ONLY in this browser, never in the app source.";
  $("labPinInput").value = "";
  dlg.showModal();
  return false;
}

function markTabs() {
  for (const p of LOCKED_LABS) {
    const b = document.querySelector(`[data-page="${p}"]`);
    if (!b) continue;
    const locked = !labsUnlocked();
    b.classList.toggle("lab-locked", locked);
    if (locked && !b.querySelector(".lock-glyph")) {
      const s = document.createElement("span");
      s.className = "lock-glyph";
      s.textContent = " 🔒";
      b.appendChild(s);
    }
    if (!locked) b.querySelector(".lock-glyph")?.remove();
  }
}

function bindGate() {
  const ok = $("labPinOk"), cancel = $("labPinCancel");
  if (!ok || ok.dataset.bound) return;
  ok.dataset.bound = "1";
  cancel.onclick = () => $("labLockGate").close();
  $("labPinInput").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); ok.click(); } });
  ok.onclick = async () => {
    const now = Date.now();
    const msg = $("labLockMsg");
    if (now < lockedUntil) { msg.textContent = "Locked after failed attempts. Wait a minute and retry."; return; }
    const pin = $("labPinInput").value || "";
    if (pin.length < 4) { msg.textContent = "PIN needs at least 4 characters."; return; }
    let saved = null;
    try { saved = localStorage.getItem(LS_PIN); } catch {}
    if (!saved) {
      await storePin(pin);
      unlockAndGo();
      return;
    }
    let okPin = false;
    try {
      okPin = await verifyPin(pin, saved);
    } catch {
      msg.textContent = "This browser cannot check the PIN (no device crypto).";
      return;
    }
    if (okPin) { fails = 0; unlockAndGo(); }
    else {
      fails++;
      if (fails >= 5) { lockedUntil = now + 60000; fails = 0; msg.textContent = "Too many tries. Locked 60s."; }
      else msg.textContent = `Wrong PIN (${fails}/5).`;
    }
  };
}

function unlockAndGo() {
  try { sessionStorage.setItem(SS_UNLOCK, "1"); } catch {}
  $("labLockGate").close();
  markTabs();
  toast("Labs unlocked for this session.");
  if (pendingPage) {
    const p = pendingPage;
    pendingPage = null;
    document.querySelector(`[data-page="${p}"]`)?.click();
  }
}

export function initOwnerLabs() {
  bindGate();
  markTabs();
}

if (document.readyState === "loading") {
  window.addEventListener("DOMContentLoaded", () => { try { initOwnerLabs(); } catch (e) { console.error("Owner labs init failed:", e); } });
} else {
  try { initOwnerLabs(); } catch (e) { console.error("Owner labs init failed:", e); }
}
