# LTX-Video 2B local human image-to-video + codec pack
Stock base: Lightricks LTX-Video 2B image-to-video (~6-8GB VRAM).
License: OpenRail-M. Commercial use is CONDITIONAL on the checkpoint you pick:
standard Lightricks checkpoints allow broad use under OpenRail-M; community
re-uploads may add their own terms. Check the checkpoint page before publishing.
No Wan2GP code is copied here; scripts use public diffusers weights directly.

## 1. Install (native, Python 3.10+)
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

## 2. Smoke test (human figure)
python run_human_ltx.py --image ./human.jpg --prompt "a person standing, gentle idle motion, breathing, blinking" --steps 30 --frames 49
Output: out/ltx_clip.mp4 + out/timing.json (load_sec, infer_sec, fps, size).

## 3. Codec round trip (no torch needed)
python codec_roundtrip.py --image ./human.jpg --video ./out/ltx_clip.mp4 --out ./out/ltx_human.soma.json
Mirrors src/ankan-soma.js layout: magic SOMA, version 1. Then open in Codec Lab -> Open.

## 4. Finetune definition (WanGP UI, conditional)
WanGP upstream documents finetunes for Wan/Hunyuan; LTX finetune support is
conditional on the checkpoint. Copy finetunes/ltx_codec_human.json into your
Wan2GP finetunes/ folder ONLY if your build lists an LTX arch id; otherwise run
standalone diffusers + LoRA and keep this JSON as the dataset spec.

## 5. What to record
GPU model, VRAM, checkpoint id, steps, frames, load_sec, infer_sec, motion quality, likeness hold, artifacts.
