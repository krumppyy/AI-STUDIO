export const ANKAN_MAGIC = "ANKAN";
export const SOMA_MAGIC = "SOMA";
export const ANKAN_SOMA_VERSION = 1;

const keyImageToDataUrl = (canvas, maxSide = 1920, q = 0.95) => {
  const w = canvas.width || 640;
  const h = canvas.height || 360;
  const s = Math.min(1, maxSide / Math.max(w, h));
  const cw = Math.max(2, Math.round(w * s));
  const ch = Math.max(2, Math.round(h * s));
  let src = canvas;
  let sw = w;
  let sh = h;
  if (s < 0.5) {
    let cur = canvas;
    let cw2 = w;
    let ch2 = h;
    while (cw2 * 0.5 >= cw && ch2 * 0.5 >= ch) {
      const step = document.createElement("canvas");
      step.width = Math.max(2, Math.round(cw2 * 0.5));
      step.height = Math.max(2, Math.round(ch2 * 0.5));
      const sx = step.getContext("2d");
      sx.imageSmoothingEnabled = true;
      sx.imageSmoothingQuality = "high";
      sx.drawImage(cur, 0, 0, step.width, step.height);
      cur = step;
      cw2 = step.width;
      ch2 = step.height;
    }
    src = cur;
    sw = cw2;
    sh = ch2;
  }
  const small = document.createElement("canvas");
  small.width = cw;
  small.height = ch;
  const sctx = small.getContext("2d");
  sctx.imageSmoothingEnabled = true;
  sctx.imageSmoothingQuality = "high";
  sctx.drawImage(src, 0, 0, sw, sh, 0, 0, cw, ch);
  return small.toDataURL("image/jpeg", q);
};

export function encodeKey(key) {
  return {
    name: key.name || "key",
    hold: Math.max(0.5, Number(key.hold) || 3),
    image: keyImageToDataUrl(key.canvas),
    analysis: {
      palette: key.analysis.palette,
      tone: {
        exposure: key.analysis.exposureLevel,
        shadow: key.analysis.toneShadow,
        highlight: key.analysis.toneHighlight,
        averageLuma: key.analysis.averageLuma,
      },
      particles: key.analysis.particles.map((p) => [
        Math.round(p.originX), Math.round(p.originY),
        +p.vx.toFixed(2), +p.vy.toFixed(2),
        p.r, p.g, p.b, +p.radius.toFixed(1), +p.alpha.toFixed(3), p.ci | 0,
      ]),
    },
  };
}

export function encodeParams(s) {
  return {
    flowVelocity: s.flowVelocity,
    exposurePulse: s.exposurePulse,
    cameraParallax: s.cameraParallax,
    morphTurbulence: s.morphTurbulence,
    colorWarp: s.colorWarp,
    density: s.particleDensity,
    transition: s.transition,
  };
}

export function encodeAnkan(canvas, analysis, params, name) {
  const image = keyImageToDataUrl(canvas);
  return {
    magic: ANKAN_MAGIC,
    version: ANKAN_SOMA_VERSION,
    width: 1280,
    height: 720,
    name: name || "ankan-still",
    params,
    key: {
      image,
      analysis: {
        palette: analysis.palette,
        tone: {
          exposure: analysis.exposureLevel,
          shadow: analysis.toneShadow,
          highlight: analysis.toneHighlight,
          averageLuma: analysis.averageLuma,
        },
        particles: analysis.particles.map((p) => [
          Math.round(p.originX), Math.round(p.originY),
          +p.vx.toFixed(2), +p.vy.toFixed(2),
          p.r, p.g, p.b, +p.radius.toFixed(1), +p.alpha.toFixed(3), p.ci | 0,
        ]),
      },
    },
  };
}

export function encodeSoma(keys, params) {
  return {
    magic: SOMA_MAGIC,
    version: ANKAN_SOMA_VERSION,
    width: 1280,
    height: 720,
    params,
    keys: keys.map(encodeKey),
  };
}

export function decodeAnkanSoma(doc) {
  if (!doc || (doc.magic !== ANKAN_MAGIC && doc.magic !== SOMA_MAGIC)) {
    throw new Error("Not an .ankan / .soma file (bad magic).");
  }
  if (doc.version !== ANKAN_SOMA_VERSION) {
    throw new Error(`Unsupported version ${doc.version}, this player reads v${ANKAN_SOMA_VERSION}.`);
  }
  const expand = (k) => {
    const a = k.analysis || {};
    const tone = a.tone || {};
    return {
      name: k.name || "key",
      hold: Math.max(0.5, Number(k.hold) || 3),
      image: k.image,
      analysis: {
        palette: a.palette || [],
        averageLuma: tone.averageLuma ?? 128,
        exposureLevel: tone.exposure ?? 50,
        toneShadow: tone.shadow ?? 15,
        toneHighlight: tone.highlight ?? 88,
        signalKB: 0,
        particles: (a.particles || []).map((q) => ({
          x: q[0], y: q[1],
          originX: q[0], originY: q[1],
          vx: q[2], vy: q[3],
          r: q[4], g: q[5], b: q[6],
          radius: q[7], alpha: q[8], ci: q[9] | 0,
          phase: Math.random() * Math.PI * 2,
        })),
      },
    };
  };
  const keys = doc.magic === ANKAN_MAGIC ? [expand({ ...doc.key, name: doc.name })] : (doc.keys || []).map(expand);
  if (!keys.length) throw new Error("File holds no keyframes.");
  return { magic: doc.magic, params: doc.params || {}, keys };
}

export const dataUrlToBlob = async (url) => (await fetch(url)).blob();

export function downloadDoc(doc, filename) {
  const str = JSON.stringify(doc);
  const blob = new Blob([str], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
  return { blob, kb: blob.size / 1024 };
}
