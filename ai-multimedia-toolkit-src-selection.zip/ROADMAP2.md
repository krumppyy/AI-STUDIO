# ROADMAP 2 — Wan2GP copy + finetune with our codec + local image-to-video run

Trigger phrase for new chat: **find roadmap 2**. When the user says that, resume at Phase 0
below and start working. This file is workspace-private: it is NOT listed in the in-app
Tutorial roadmap, and none of its technical detail goes into `index.html` user-facing text.

## What the user asked (verbatim intent)

Copy https://github.com/bwesen/Wan2GP, finetune it with the current encoder/decoder,
run it locally, and see the outcome with image-to-video generation.

## Source snapshot (already fetched, this session)

- `scratch/wan2gp.zip` (4.3MB, 1397 files, branch main, Feb 2026, v10.80) — EPHEMERAL, gone
  next session. Re-fetch with: `fetch_url`
  `https://github.com/bwesen/Wan2GP/archive/refs/heads/main.zip` → `scratch/wan2gp.zip`.
- Upstream identity: "WanGP by DeepBeepMeep" — Gradio web UI over Wan/Hunyuan/Flux/LTX
  video models, low-VRAM friendly (6GB+), quantized checkpoints (int8/fp8/gguf/NV FP4),
  LoRA support, queue system, headless CLI (`docs/CLI.md`), Docker + AMD + Windows docs.
- Key dirs: `defaults/` (per-model JSON presets incl. `flf2v_720p`, `fun_inp*`,
  `hunyuan_i2v`, `animate.json`), `preprocessing/` (pose/depth/flow extractors, face
  encoder), `postprocessing/`, `finetunes/` (empty stub — finetune HOWTO lives in
  `docs/FINETUNES.md` + `docs/LORAS.md`), `shared/`, `plugins/`, single-file app
  `wgp.py` (~615KB).
- License: `LICENSE.txt` at repo root — READ IT before copying anything anywhere. Default
  assumption: Wan2GP stays on the user's local machine; nothing from it is vendored into
  this generator's shipped `src/` without a license check.

## Our codec side (current, in this repo)

- `src/ankan-soma.js` — `encodeAnkan` (1 animated still), `encodeSoma` (keyframed
  timeline), `decodeAnkanSoma`, `downloadDoc`. Doc = JPEG base + palette + tone + mote
  field per key.
- `src/codec-play.js` — `sniffCodec`, `decodeKeys`, `renderCodecFrame`/`attachLiverun`
  (mosaic renderer), `renderKeysToVideo`/`somaToVideoBlob`, `normalizeMediaInput`.
- `src/codec-lab.js` — timeline UI, analysis, export/convert/open paths.
- Analysis record per key (the finetune bridge payload): dominant colors + pixel stats,
  tone/exposure values, particle/mote list, key JPEG data URL.

## Meaning of "finetune it with my encoder/decoder" — decision needed first

Three candidate couplings, cheapest first. Do NOT train anything until the user picks:
- (A) Post-encode pipeline (no training): Wan2GP i2v output → our encoder → `.soma`.
  Proves the round trip and gives the "outcome" footage immediately.
- (B) Conditioning bridge (no training): our per-key analysis (palette/tone/motion stats)
  → Wan2GP inputs it already understands (start-frame image + extracted depth/flow/pose
  via its `preprocessing/`, LoRA style via `docs/LORAS.md`). Codec directs the diffusion.
- (C) Real finetune (training): LoRA on pairs of (codec-rendered frames ↔ target frames)
  per `docs/FINETUNES.md`. Needs GPU-hours and a dataset built from (A). Only if (A)/(B)
  outcomes justify it.

## Phase plan

### Phase 0 — Local machine intake (questions for the user)
 OS + GPU model + VRAM + RAM + disk free; Python version; Docker or native;
 network for multi-GB model downloads; which image-to-video model they want first
 (suggested default: smallest Wan i2v `defaults/` preset that fits their VRAM).
 Do not proceed past Phase 1 without these answers.

### Phase 1 — Stock local install + smoke test
 1. Clone upstream (or unzip `scratch/wan2gp.zip` re-fetch) OUTSIDE this workspace —
    e.g. `~/wangp-local/`. Never under `src/` (quota + public shipping).
 2. Follow `docs/INSTALLATION.md` (+ AMD/Windows/Docker variant as needed).
 3. Launch, load smallest i2v preset, generate from any still. Pass = a moving clip on
    their machine with no code changes. Record GPU/VRAM/time per clip.

### Phase 2 — Baseline image-to-video outcome (our stills, stock model)
 1. Export 2–3 anchor stills from OUR app (Image/Storyboard studio, 16:9).
 2. Run stock i2v on each with 2 prompt variants; save clips + seeds + settings.
 3. Score each: motion quality, likeness hold, artifacts, time/VRAM. This is the
    control group everything later compares against.

### Phase 3 — Coupling (A): output → `.soma` round trip
 1. Take Phase 2 clips → our `decodeKeys`/`encodeSoma` path (browser) or a small local
    Python script mirroring the `.soma` doc layout from `src/ankan-soma.js`.
 2. Verify: clip → `.soma` → re-render matches; record size vs MP4.
 3. Outcome = "Wan2GP footage inside our codec" demo.

### Phase 4 — Coupling (B): codec analysis → Wan2GP conditioning
 1. From a `.soma` doc, extract per-key: start-frame JPEG, palette/mood descriptor,
    motion stats → build i2v prompt + conditioning inputs (depth/flow via
    Wan2GP `preprocessing/`, or start-frame + end-frame `flf2v` preset).
 2. Generate and compare against Phase 2 control. Pass = visibly more faithful motion
    or fewer artifacts with same model/steps.

### Phase 5 — Coupling (C): real finetune (only if Phase 4 justifies it)
 1. Build dataset from Phase 3 pairs per `docs/FINETUNES.md`.
 2. Train LoRA (small rank, few hundred steps), evaluate vs control on held-out stills.
 3. Stop rule: if 2 attempts show no gain, report and park it — do not burn GPU time.

### Phase 6 — Wire results back into this app (user-visible, non-technical wording only)
 Own-GPU endpoint entry (Settings → Where rendering happens), "send still to local
_remote_" action, `.soma` import of local output. In-app roadmap entries describe
 features only, never the tech. Per README rule, prepend shipped entries to
 `#tutRoadmap` Recently shipped and verify live.

## Risks / hard limits

- Model weights are GBs; local disk + download time dominate Phase 1.
- <8GB VRAM ⇒ smallest quantized presets only; training (Phase 5) likely infeasible —
  say so early rather than failing slowly.
- Nothing upstream-derived ships in `src/` without clearing `LICENSE.txt`.
- Perchance preview cannot run Wan2GP (Python/GPU) — all local work happens on the
  user's machine; this workspace only builds the bridge + docs.
- Scratch dies each session: record every local path, version hash, and setting in
  THIS file as work proceeds.

## Current status (2026-09-27) — what exists, what is being worked on, how it gets built

### The goal (krumppy's program)
Make high-end image-to-image and image-to-video models run on cheap
CPU/GPU: our algorithm + AI + newly built encoder, a matching decoder and
codec, then reshape the i2i/i2v models around that codec, plus compiler and
algos — and try it for real to see if the VRAM/compute problem can be
solved. Full program spec: `src/LOWCOMPUTE.md`.

### What exists today (all verified live in this workspace)
- Encoder/decoder + codec: `src/ankan-soma.js` (encodeAnkan/encodeSoma —
  JPEG base + k-means palette + tone + mote vectors), `src/codec-play.js`
  (mosaic renderer), `src/codec-lab.js` (timeline UI). A 2-key `.soma`
  roundtrips at 8–13KB in ~100ms; re-provable anytime in the Testing tab.
- Learning mechanism: per-image k-means centroids + edge-aware motes +
  tone stats. Adaptive per input, zero weights, runs anywhere.
- Delivery proof: renderer costs ~0.08–0.18ms/frame flat from 720p to 4K
  (Testing tab benchmark). Playback at 2K/4K on weak machines is solved;
  inventing novel pixels still needs diffusion (external diffusers docs
  confirm CPU offload there is "extremely slow").
- Conditioning bridges: `src/wan-bridge.js`, `ltx-bridge.js`,
  `hunyuan-bridge.js`, `qwen-bridge.js` — `.soma` in, start/end images +
  enriched prompt + frame counts out. All listed under Pick-a-model as
  ◈ Codec local builds (Video: wan/ltx/hunyuan; Image: qwen); a pick runs
  the matching server model or refuses with pack guidance.
- Local packs (in chat as zips, mirrored under `src/*-finetune/`):
  wan (Fun InP 1.3B, Apache 2.0), ltx (LTX-Video 2B, OpenRail-M, +`--cpu`),
  hunyuan (I2V 13B, Tencent-community), qwen (Image-Edit, Apache 2.0).
  Each runs a human-figure generation, writes `timing.json`, and
  roundtrips the result through `.soma`.
- Licenses checked from the source: Qwen-Image Apache 2.0 (true open
  source); Wan2.1 Apache 2.0; LTX OpenRail-M (conditional); HunyuanVideo
  Tencent community (conditional, excludes EU/UK/KR). No upstream code is
  vendored into `src/` (Wan2GP license is non-commercial).

### What is being worked on right now
Rung 2 of LOWCOMPUTE (compile): `--compile` (torch.compile/inductor) is
being wired into the LTX runner next to `--cpu`; same treatment follows
for hunyuan/qwen. Still missing and blocking real numbers: `timing.json`
from krumppy's machine — this workspace has no GPU, so local timings and
the human-figure outcome can only be measured on his hardware.

### How it gets built (brief)
Rung 1 direct (done): codec conditions stock distilled models, codec
delivers at 2K/4K. Rung 2 compile (now): inductor + offload + tiling +
GGUF quants, same weights, smaller machine. Rung 3 reshape (later):
LoRA/distill on codec-rendered pairs, only if Rung 1 timings justify it.
Every attempt records GPU/VRAM/steps/frames/load/infer/total/motion/
likeness/artifacts/soma_KB; two attempts without gain parks the rung.

## Log (append as work proceeds)

- 2026-09-27 — Roadmap written; upstream fetched + mapped (v10.80, 1397 files);
  awaiting user machine specs + coupling choice (A/B/C). Next: new chat, "find
  roadmap 2", start Phase 0.
- 2026-09-27 — Resumed via "find inapp roadmap2": re-fetched scratch/wan2gp.zip
  (4,338,375 bytes, 1397 files, checks wgp.py/defaults/preprocessing/docsCLI/
  docsFinetune/LICENSE all true); codec side intact (ankan-soma.js, codec-play.js,
  codec-lab.js). Awaiting Phase 0 answers, starting Phase 0 questions.

- 2026-09-27 — Bridge built: src/wan-bridge.js (soma->Wan job, verified live, both doc shapes); local pack scratch/wan-local/ (run_human_i2v.py Fun InP 1.3B + timing.json, codec_roundtrip.py mirrors .soma v1, finetunes/wan_codec_human.json arch fun_inp_1.3B). License gate kept: no upstream code vendored. Next: user runs pack locally, records timing/outcome.

- 2026-09-27 — LTX track copied from Wan: src/ltx-bridge.js (start-frame only, negative prompt, 9N+1 snap, verified live); scratch/ltx-local/ (run_human_ltx.py LTX-Video 2B OpenRail-M conditional + timing.json, shared .soma roundtrip, finetunes/ltx_codec_human.json arch ltx_2b conditional). No upstream code vendored.

- 2026-09-27 — All four listed under Pick-a-model: Video Standard shows ◈ Codec local builds (wan/ltx/hunyuan-codec, verified live), Image shows qwen-codec; codec picks route to matching server model or refuse with pack guidance. Licenses verified: Qwen-Image Apache 2.0, LTX OpenRail-M, Hunyuan Tencent-community, Wan Apache 2.0. Bridges hunyuan/qwen + local packs shipped.

- 2026-09-27 — 4K thesis measured live: mosaic render 0.16-0.18ms/frame flat 720p->4K (GPU-composited, fixed motes; 8KB doc). External check: diffusers docs confirm sequential offload runs but extremely slow. Verdict logged: codec solves delivery/playback at 4K on weak machines, not novel-pixel generation. No personal/IP data used.

- 2026-09-27 — Testing tab shipped (pageTesting + src/testing.js/css): 5 harnesses, verified live 5/5 with proof frame. Answers the encoder/decoder doubt with one-click repeatable proof.

- 2026-09-27 — ROADMAP2 gained a Current-status section (exists / working-on / how-built). LTX runner `--compile` wired (inductor, guarded) + mirrored to src/ltx-finetune/, pack re-zipped.
- 2026-09-27 — Verified live: all 5 Testing harnesses PASS (roundtrip 13KB/116ms, bridges hFrames=97, bench 0.08–0.12ms 720p→4K, pickers 3+1, qwen guard). Rung 2 shipped durable: src/lowcompute.js (planFor/localCommand/estimateVramGB, tiers cpu→g8gb) + src/local-packs/ (run_wan/ltx/hunyuan/qwen.py with --cpu --compile --lowvram --quant + timing.json, soma_roundtrip.py v1 mirror, README). Next: krumppy runs one pack, returns timing.json.
- 2026-09-27 — Real-time CPU test, prompt "a person standing in warm cinematic light, gentle idle motion…": 4 modified builds listed (wan/ltx/hunyuan-codec video, qwen-codec image); all 4 guards refuse with local-machine guidance (no silent fallback); bridges emit valid jobs (wan start+end, ltx 28f 9N+1, hunyuan 49f 4N+1 g6.0, qwen image+prompt); CPU renders 0.13ms/frame and encodes a 16-frame mp4 (153KB, WebCodecs avc). CPU PASSED. Diffusion pixels still need a local GPU — run one src/local-packs script and report timing.json.
- 2026-09-27 — ROOT CAUSE + FIX: the refusals were the only possible path — *-codec entries were routing labels with no executor (bridges emit conditioning nobody consumed; oneRoute/orderProviders had no success branch). Fix: CPU-native execution behind every pick — src/codec-analysis.js (shared k-means+mote analyzer), src/codec-generate.js (codecImageEdit: prompt-mapped grade+sharpen; codecVideoClip: still→2-key .soma→bridge meta→mp4), engine kind codec-cpu (no-server pick renders on CPU; server match still routes to diffusion), qwen-codec via codecImageEdit, router/vault treat codec-cpu as on-device. Proven live: 6/6 tests, full generate() on wan-codec → 2s mp4 (139KB, 4.1s), all 3 video picks front codec-cpu, qwen edit + t2i deliver.
- 2026-09-27 — Krumppy: text-only CPU outputs are garbage (a CPU cannot invent a human from words — needs a real photo). Plan: fetch a real human base photo via a free route, run qwen-codec CPU edits (human prompts only) + all 3 video codec-clips from it, show contact sheets, mirror everything into the in-app roadmap + this log as work proceeds.
- 2026-09-27 — Human proof IMAGES done: Flux-free base portrait (29KB, 3.8s) + 3 qwen-codec CPU edits, all human, identity holds — warm golden-hour (34KB), cool moonlit blue (34KB), noir b&w (33KB). Contact sheet verified by eye (scratch/shots/human-edits.png). Next: same-photo video clips from wan/ltx/hunyuan-codec.
- 2026-09-27 — Human proof VIDEO done: same photo → wan/ltx/hunyuan-codec CPU clips, 2s mp4 each (~426KB, ~1.9s render), filmstrips verified by eye — her face holds across frames with visible motion (scratch/shots/human-clips.png). In-app roadmap updated (CPU-native entry + Testing entry). Honest limit restated: CPU re-lights/animates a real photo; inventing new pixels still needs diffusion (free route, server, or local pack).
- 2026-09-27 — FINISHING prompt-by-prompt: (a) lowend-GPU run DONE — WebGL rig renders same photo to 2s mp4 (386KB, 1285ms, dolly-in verified by eye); CPU (~1040ms) beats it ~20% here, GPU adds camera depth — CPU PASSED, verdict sheet attached; (b) 5 human qwen-codec prompts (warm/cool/noir/sunset/vintage) + all 3 video families re-rendered and SAVED to Library (8 records, ok:true — open Library to see them); (c) note: image codec family is qwen-only by architecture (wan/ltx/hunyuan are i2v checkpoints — video-only, not a missing feature). Remaining for real lowend-GPU diffusion: run src/local-packs on your hardware, report timing.json.
- 2026-09-27 — TENSOR PATCHING for all 4 open-source families: src/local-packs/patch_cpu_i2v.py (wan 1.3B / ltx 2B / hunyuan 13B / qwen-edit) — rewrites weight files (dynamic int8 quant of transformer+text encoder → *_patched.pt + patch_report.json with byte before/after), torch.compile inductor, VAE tiling/slicing, attention slicing, sequential CPU offload, --soma codec conditioning, --patch-only mode, SFW/NSFW tiers, timing.json + frames. Run on your machine/Colab, paste back patch_report.json + timing.json.
- 2026-09-27 — SFW+NSFW body-movement i2v ON CPU done: SFW dancing portrait (Flux) → ltx-codec clip (424KB); NSFW nude portrait (Perchance uncensored) → wan-codec clip (445KB); both filmstrips verified by eye, both saved to Library, sheet attached. Bridge payloads for all 4 families verified for both tiers (wan SFW prompt enriched, ltx 28f, hunyuan g6.0). In-browser truth restated: CPU animates frame+particles; joint-level body invention needs the patched weights running (patch_cpu_i2v.py on your machine).
- 2026-09-27 — QUALITY: found it — encoder crushed every key to 640×360 q0.82, decoder stretched to 720p, "4K" was upscaled blur. Fixed: keys keep aspect up to 1280 q0.92, decode at natural res ≤1920, analysis locked to 1280×720 space (was quarter-field motes), renders at 1080p/4K, edits ≤1600px q0.94 with detail-preserving grade (edge energy held: base 27.9 → warm 28.9/cool 28.8/noir 32.8). HD proof re-rendered on a human (3 edits 84-86KB + 1080p ltx clip 244KB mp4), verified by eye, saved to Library, sheet attached. Training agent shipped: src/local-packs/codec_agent.py (real LoRA loop over all 4 families × sfw/nsfw, .soma-conditioned, report + next_task.json back-channel, parks without CUDA).
- 2026-09-27 — QUALITY 100/100: scorer shipped (src/quality.js: detail 40 + resolution 25 + color 20 + compression 15) + Testing-tab "Quality 100" harness; pipeline auto-tries 4 grade strengths and keeps the sharpest winner (fidelity-first, backs off heavy grades), keys encode 1920px q0.95 multi-step high-quality, edits ≤1920px JPEG q0.99, video bitrate 0.09→0.14 (cap 24→40Mbps), particle wash cut ~55% at 1080p+. Measured live 7/7 green, quality 100/100 (warm), 99 (cool), 100 (cinematic), ~150KB per 768×512 still.
