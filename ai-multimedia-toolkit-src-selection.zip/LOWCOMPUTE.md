# LOW-COMPUTE PROGRAM — high-end i2i/i2v on cheap CPU/GPU

Goal (krumppy's words, cleaned): modify high-end image-to-image and
image-to-video models so they run on low-cost CPU/GPU. Means: our own
algorithm + AI + newly built encoder, a matching decoder and codec, then
reshape the i2i/i2v models around that encoder/decoder, plus a compiler,
algos, and real tries to see if the decade problem (VRAM/compute hunger)
can be solved.

## What exists already (measured, not assumed)

- Encoder/decoder + codec: `src/ankan-soma.js` (encodeAnkan/encodeSoma,
  per-key JPEG base + k-means palette + tone + mote vectors),
  `src/codec-play.js` (mosaic renderer), `.soma` 8–13KB per scene.
- Learning mechanism: per-image k-means true centroids, edge-aware mote
  placement, tone stats — adaptive per input, no weights, runs anywhere.
- Delivery proof: 0.08–0.18ms/frame flat 720p→4K in the Testing tab.
- Conditioning bridges: wan/ltx/hunyuan/qwen (`src/*-bridge.js`) — codec
  analysis drives the diffusion model's inputs.
- Local packs: `*-local-pack.zip` in chat (run + time + `.soma` roundtrip).

## What "modify the model" really means (three rungs, cheapest first)

- Rung 1 — direct, no training: codec conditions a stock distilled model
  (few steps, low res), codec delivers at 2K/4K. Only the pipeline is new.
- Rung 2 — compile + quantize: torch.compile (inductor), sequential CPU
  offload, VAE tiling/slicing, GGUF Q4 weights where published. Same
  weights, less machine. This is the "compiler" half of the thought.
- Rung 3 — reshape weights: LoRA/distill against codec-rendered pairs so
  the model natively speaks codec latents. Needs GPU-hours + dataset from
  Rung 1. Only if Rungs 1–2 justify it.

## Try protocol (every attempt records the same table)

GPU/VRAM/RAM · checkpoint · steps · frames · resolution · load_sec ·
infer_sec · total_sec · motion score · likeness hold · artifacts ·
soma_KB. Stop rule: two attempts, no gain → park it, report honestly.

## Status

Rung 1 shipped (bridges + packs). Rung 2 started (`--compile` on the LTX
runner). Rung 3 spec'd (finetune JSONs), awaiting Rung 1 timings from a
real machine — this workspace has no GPU, so local numbers must come from
krumppy's hardware.

## Rung 2 shipped (2026-09-27): planner + durable local packs

- `src/lowcompute.js` — `planFor(family, tier)` + `localCommand` +
  `estimateVramGB`. Tiers cpu/igpu-2gb/g4gb/g6gb/g8gb. Weak tiers get
  4–6 steps, 360–480p, sequential offload, inductor compile, fp8/int8
  where published. Same weights, smaller machine — the compiler half.
- `src/local-packs/` — `run_wan.py`, `run_ltx.py`, `run_hunyuan.py`,
  `run_qwen.py` (each: lazy diffusers load, `--cpu --compile --lowvram
  --quant`, VAE tiling, `timing.json`), `soma_roundtrip.py` (stdlib-only
  `.soma` v1 mirror matching `src/ankan-soma.js`), README with the try
  protocol. Durable: ships with the generator, unlike scratch zips.
- Next: krumppy runs one pack on his hardware, pastes back `timing.json`
  + motion/likeness/artifacts/soma_KB. Two attempts without gain parks it.
