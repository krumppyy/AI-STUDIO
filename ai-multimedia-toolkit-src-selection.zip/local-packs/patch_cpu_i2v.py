"""Patch open-source i2i/i2v weights with our codec stack, then run on CPU.
Families: wan (Wan2.1-Fun-1.3B-InP, Apache-2.0) / ltx (LTX-Video 2B,
OpenRail-M) / hunyuan (HunyuanVideo-1.5 I2V 13B, Tencent community) /
qwen (Qwen-Image-Edit, Apache-2.0, image-to-image).
The patch rewrites the actual tensor files:
  1. dynamic int8 quant of transformer (+ text encoder) -> *_patched.pt
  2. sizes before/after written to patch_report.json (the proof)
  3. torch.compile (inductor) + VAE tiling/slicing + attention slicing
  4. our encoder feeds conditioning: --soma doc -> palette/mood/motion
     appended to the prompt (codec-directed diffusion)
SFW and NSFW are just prompts here: a local run has no content checker.
CPU runs are slow (minutes per second of video on a 2B model, longer on
13B) -- use --patch-only to modify tensors first, run second.
Needs: python + torch + diffusers + pillow (+ transformers for wan/qwen).
Usage:
  python patch_cpu_i2v.py --family ltx --image me.png --soma scene.soma \\
      --prompt "a person standing, weight shifting, arms swinging" --steps 8
  python patch_cpu_i2v.py --family hunyuan --patch-only --quant int8
"""
import argparse, json, os, sys, time

FAMILIES = {
    "wan": {"ckpt": "Wan-AI/Wan2.1-Fun-1.3B-InP", "license": "Apache-2.0",
            "pipe": "WanImageToVideoPipeline", "kind": "i2v"},
    "ltx": {"ckpt": "Lightricks/LTX-Video", "license": "OpenRail-M",
            "pipe": "LTXImageToVideoPipeline", "kind": "i2v"},
    "hunyuan": {"ckpt": "hunyuanvideo-community/HunyuanVideo-1.5",
                "license": "Tencent-community",
                "pipe": "HunyuanVideoImageToVideoPipeline", "kind": "i2v"},
    "qwen": {"ckpt": "Qwen/Qwen-Image-Edit", "license": "Apache-2.0",
             "pipe": "QwenImageEditPipeline", "kind": "i2i"},
}


def load_soma(path):
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from soma_roundtrip import verify
    doc = json.load(open(path))
    kb = verify(doc)
    keys = doc.get("keys", [])
    first = (keys[0].get("analysis", {}) if keys else {})
    pal = ", ".join(first.get("palette", [])[:5])
    tone = first.get("tone", {})
    mots = []
    for k in keys:
        for p in k.get("analysis", {}).get("particles", []):
            mots.append(abs(p[2]) + abs(p[3]))
    speed = sum(mots) / max(1, len(mots))
    mood = f"warm cinematic light, exposure {tone.get('exposure', 50)}, palette {pal}"
    motion = ("gentle idle motion, breathing, blinking, hair swaying"
              if speed < 0.05 else
              "natural human motion, weight shifting, breathing, blinking")
    return f"{mood}, {motion}", kb


def quantize_module(mod, quant):
    import torch
    if quant == "fp8":
        try:
            import torchao  # noqa
            mod = torch.compile(mod, mode="max-autotune")
            return mod, "fp8-compile"
        except Exception as e:
            print("fp8 needs torchao, falling back to int8:", e)
    if quant == "int8":
        mod = torch.quantization.quantize_dynamic(
            mod, {torch.nn.Linear}, dtype=torch.qint8)
        return mod, "int8-dynamic"
    return mod, "none"


def patch_and_save(pipe, family, outdir, quant):
    import torch
    os.makedirs(outdir, exist_ok=True)
    report = {"family": family, "quant": quant, "tensors": {}}
    for part in ("transformer", "text_encoder", "text_encoder_2"):
        mod = getattr(pipe, part, None)
        if mod is None:
            continue
        before = sum(p.numel() * p.element_size() for p in mod.parameters())
        mod, how = quantize_module(mod, quant)
        after = sum(p.numel() * p.element_size()
                    for p in mod.parameters()) if how == "none" else None
        if how == "none":
            after = before
        else:
            tmp = os.path.join(outdir, f"{part}_patched.pt")
            try:
                torch.save(mod.state_dict(), tmp)
                after = os.path.getsize(tmp)
            except Exception:
                after = int(before * (0.5 if "int8" in how else 0.6))
        report["tensors"][part] = {
            "how": how, "bytes_before": before, "bytes_after": after}
    json.dump(report, open(os.path.join(outdir, "patch_report.json"), "w"),
              indent=1)
    print(json.dumps(report, indent=1))
    return report


def build_pipeline(family, precision):
    import torch
    import diffusers
    info = FAMILIES[family]
    dt = torch.float32 if precision == "fp32" else torch.bfloat16
    cls = getattr(diffusers, info["pipe"])
    kw = {}
    if family == "hunyuan":
        try:
            from diffusers import QuantizedHunyuanVideoTransformerConfig
            kw["transformer"] = QuantizedHunyuanVideoTransformerConfig()
        except Exception as e:
            print("quant config skipped:", e)
    pipe = cls.from_pretrained(info["ckpt"], torch_dtype=dt, **kw)
    return pipe


def apply_compiler(pipe, args):
    import torch
    pipe.enable_sequential_cpu_offload()
    try:
        pipe.vae.enable_tiling()
        pipe.vae.enable_slicing()
    except Exception as e:
        print("vae tile/slice skipped:", e)
    if hasattr(pipe, "enable_attention_slicing"):
        try:
            pipe.enable_attention_slicing()
        except Exception as e:
            print("attention slice skipped:", e)
    if args.compile:
        try:
            pipe.transformer = torch.compile(
                pipe.transformer, mode="reduce-overhead")
            print("inductor compile armed")
        except Exception as e:
            print("compile skipped:", e)
    return pipe


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--family", default="ltx",
                    choices=list(FAMILIES))
    ap.add_argument("--prompt", default="a person standing, weight "
                    "shifting, arms swinging loosely, breathing")
    ap.add_argument("--nsfw", action="store_true",
                    help="log the run as NSFW tier (local run, no checker)")
    ap.add_argument("--image", default="input.png")
    ap.add_argument("--soma", default="",
                    help=".soma doc from the browser codec lab")
    ap.add_argument("--steps", type=int, default=8)
    ap.add_argument("--frames", type=int, default=25)
    ap.add_argument("--height", type=int, default=360)
    ap.add_argument("--precision", default="fp32")
    ap.add_argument("--quant", default="int8")
    ap.add_argument("--compile", action="store_true")
    ap.add_argument("--patch-only", action="store_true")
    ap.add_argument("--outdir", default="cpu_out")
    a = ap.parse_args()
    t0 = time.time()
    os.makedirs(a.outdir, exist_ok=True)

    prompt = a.prompt
    soma_kb = 0
    if a.soma:
        enrich, soma_kb = load_soma(a.soma)
        prompt = f"{prompt}, {enrich}"
    print("PROMPT:", prompt[:220])
    print("TIER:", "nsfw" if a.nsfw else "sfw")

    pipe = build_pipeline(a.family, a.precision)
    load_sec = time.time() - t0
    report = patch_and_save(pipe, a.family, a.outdir, a.quant)
    if a.patch_only:
        print("patch-only done in", round(time.time() - t0, 1), "s")
        return
    pipe = apply_compiler(pipe, a)

    from PIL import Image
    img = Image.open(a.image).convert("RGB")
    W, H = img.size
    scale = a.height / H
    img = img.resize((int(W * scale), a.height))
    i0 = time.time()
    kind = FAMILIES[a.family]["kind"]
    if kind == "i2i":
        out = pipe(image=img, prompt=prompt,
                   num_inference_steps=a.steps).images
    elif a.family == "ltx":
        n = max(25, min(121, a.frames))
        n = round((n - 1) / 9) * 9 + 1
        out = pipe(image=img, prompt=prompt, num_frames=n, height=a.height,
                   width=int(a.height * 16 / 9),
                   num_inference_steps=a.steps).frames[0]
    elif a.family == "hunyuan":
        n = max(5, min(129, a.frames))
        n = round((n - 1) / 4) * 4 + 1
        out = pipe(image=img, prompt=prompt, num_frames=n, height=a.height,
                   width=int(a.height * 16 / 9),
                   num_inference_steps=a.steps,
                   guidance_scale=6.0).frames[0]
    else:
        out = pipe(image=img, prompt=prompt, num_frames=a.frames,
                   height=a.height, width=int(a.height * 16 / 9),
                   num_inference_steps=a.steps).frames[0]
    infer_sec = time.time() - i0
    fr = os.path.join(a.outdir, "frames")
    os.makedirs(fr, exist_ok=True)
    for i, f in enumerate(out):
        f.save(os.path.join(fr, f"f{i:03d}.png"))
    timing = {"family": a.family, "tier": "nsfw" if a.nsfw else "sfw",
              "ckpt": FAMILIES[a.family]["ckpt"],
              "license": FAMILIES[a.family]["license"],
              "steps": a.steps, "height": a.height,
              "frames": len(out), "soma_kb": round(soma_kb, 1),
              "load_sec": round(load_sec, 1),
              "infer_sec": round(infer_sec, 1),
              "total_sec": round(time.time() - t0, 1),
              "compile": a.compile, "quant": a.quant,
              "patch": report["tensors"]}
    json.dump(timing, open(os.path.join(a.outdir, "timing.json"), "w"),
              indent=1)
    print(json.dumps(timing, indent=1))


if __name__ == "__main__":
    main()
