"""Shared .soma v1 mirror (stdlib only). Layout matches src/ankan-soma.js."""
import json

MAGIC = \"SOMA\"
VERSION = 1

def make_key(name, hold, image_b64, palette, tone, particles):
    return {
        \"name\": name, \"hold\": hold, \"image\": image_b64,
        \"analysis\": {\"palette\": palette, \"tone\": tone, \"particles\": particles},
    }

def make_doc(keys, params):
    return {\"magic\": MAGIC, \"version\": VERSION, \"width\": 1280, \"height\": 720,
            \"params\": params, \"keys\": keys}

def verify(doc):
    assert doc.get(\"magic\") == MAGIC, \"bad magic\"
    assert doc.get(\"version\") == VERSION, \"bad version\"
    assert len(doc.get(\"keys\", [])) > 0, \"no keys\"
    raw = json.dumps(doc)
    back = json.loads(raw)
    assert back[\"magic\"] == MAGIC and len(back[\"keys\"]) == len(doc[\"keys\"])
    return len(raw) / 1024
