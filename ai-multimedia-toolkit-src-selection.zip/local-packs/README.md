# Local packs — run the codec-conditioned models on your own machine

Each script generates one human-figure image/video with the matching
diffusers checkpoint, writes `timing.json`, and mirrors the `.soma` v1
doc layout from `src/ankan-soma.js` (see `soma_roundtrip.py`).
Nothing here runs in the Perchance preview — copy one file to a machine
with Python + torch and run it there.

Planner: `src/lowcompute.js` (`planFor` + `localCommand`) picks steps /
resolution / offload / compile flags per hardware tier. Tiers: cpu,
igpu-2gb, g4gb, g6gb, g8gb.

| script | checkpoint | license |
| --- | --- | --- |
| `run_wan.py` | Wan Fun InP 1.3B | Apache 2.0 |
| `run_ltx.py` | LTX-Video 2B | OpenRail-M (conditional) |
| `run_hunyuan.py` | HunyuanVideo I2V 13B | Tencent community (conditional) |
| `run_qwen.py` | Qwen-Image-Edit | Apache 2.0 |

Record every attempt per the try protocol in `src/LOWCOMPUTE.md`:
GPU/VRAM/RAM, checkpoint, steps, frames, resolution, load/infer/total
sec, motion, likeness, artifacts, soma_KB. Two attempts, no gain: park it.

## The training agent (Rung 3)

`codec_agent.py` loops families × tiers with our encoder in the loop:
reads a `.soma` doc for conditioning, trains a real LoRA (peft,
needs CUDA), scores sharpness/size/time, and writes two files —
`agent_report.json` (human-readable) and `next_task.json`
(machine-readable follow-up for the app-side agent: paste it back into
chat and the loop continues here). Stop rule: two attempts without gain
→ PARKED. Without CUDA/peft it says so instead of faking numbers.
