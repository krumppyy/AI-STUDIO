"""Codec agent: trains each open-source tensor file WITH our codec logic.
Loop over families (wan/ltx/hunyuan/qwen) x tiers (sfw/nsfw):
  1. READ our encoder: --soma doc -> palette/mood/motion conditioning
     (same analysis the browser lab wrote; see soma_roundtrip.py).
  2. BUILD pairs: (codec-rendered frame, target frame) from --pairs dir,
     or diffusion pairs from the base checkpoint when empty.
  3. TRAIN LoRA (peft, real weights update) on the family checkpoint.
     Needs GPU + `pip install peft`. Without peft/GPU it reports
     CANNOT-TRAIN honestly instead of faking numbers.
  4. SCORE vs control: sharpness (Laplacian variance), bytes, infer_sec.
  5. WRITE agent_report.json (for the human) + next_task.json (for the
     app agent: machine-readable follow-up, e.g. {"need": "more-pairs",
     "family": "hunyuan", "tier": "nsfw"}). That file pair IS the
     interaction with the app-side agent -- paste them back into chat
     and it continues the loop here.
STOP RULE: two attempts without gain -> status PARKED, no more GPU burn.
Usage:
  python codec_agent.py --family ltx --tier sfw --soma scene.soma \\
      --prompt "a woman dancing softly" --pairs ./pairs --steps 200
"""
import argparse, glob, json, os, time

FAMILIES = ["wan", "ltx", "hunyuan", "qwen"]


def sharpness(path):
    try:
        from PIL import Image, ImageFilter
        im = Image.open(path).convert("L").resize((160, 90))
        px = list(im.getdata())
        W, H = 160, 90
        tot, n = 0.0, 0
        for y in range(1, H - 1):
            for x in range(1, W - 1):
                i = y * W + x
                lap = abs(4 * px[i] - px[i - 1] - px[i + 1]
                          - px[i - W] - px[i + W])
                tot += lap
                n += 1
        return round(tot / n, 2)
    except Exception:
        return 0.0


def read_encoder(soma_path, prompt):
    enrich, kb = "", 0
    if soma_path and os.path.exists(soma_path):
        import sys
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        from soma_roundtrip import verify
        doc = json.load(open(soma_path))
        kb = verify(doc)
        keys = doc.get("keys", [])
        a = keys[0].get("analysis", {}) if keys else {}
        pal = ", ".join(a.get("palette", [])[:5])
        enrich = (f", warm cinematic light, palette {pal}, "
                  f"exposure {a.get('tone', {}).get('exposure', 50)}")
    return prompt + enrich, kb


def train_lora(family, tier, pairs, prompt, steps, outdir):
    """Real LoRA update. Returns (ok, detail). No GPU/peft -> honest no."""
    import torch
    if not torch.cuda.is_available():
        return False, "no-CUDA: LoRA needs a GPU; run on Colab/Kaggle"
    try:
        from peft import LoraConfig, get_peft_model
    except Exception:
        return False, "no-peft: pip install peft to train"
    files = sorted(glob.glob(os.path.join(pairs, "*.png")))
    if len(files) < 4:
        return False, f"need 4+ pair frames, found {len(files)}"
    from patch_cpu_i2v import build_pipeline
    pipe = build_pipeline(family, "bf16").to("cuda")
    cfg = LoraConfig(r=8, lora_alpha=16,
                     target_modules=["to_q", "to_k", "to_v", "to_o"],
                     lora_dropout=0.05)
    try:
        pipe.transformer = get_peft_model(pipe.transformer, cfg)
    except Exception as e:
        return False, f"lora-attach-failed: {e}"
    opt = torch.optim.AdamW(pipe.transformer.parameters(), lr=1e-4)
    import torch.nn.functional as F
    from PIL import Image
    ims = []
    for f in files[:8]:
        im = Image.open(f).convert("RGB").resize((256, 144))
        t = torch.from_numpy(__import__("numpy").array(im)).float()
        t = t.permute(2, 0, 1).unsqueeze(0) / 127.5 - 1.0
        ims.append(t)
    batch = torch.cat(ims).to("cuda", dtype=torch.bfloat16)
    with torch.no_grad():
        lat = pipe.vae.encode(batch).latent_dist.sample()
        lat = lat * getattr(pipe.vae.config, "scaling_factor", 0.18215)
        enc = pipe.encode_prompt(full_prompt)
        prompt_embeds = enc[0] if isinstance(enc, tuple) else enc
    sched = pipe.scheduler
    t0 = time.time()
    pipe.transformer.train()
    done, lval = 0, 0.0
    for _ in range(min(steps, 200)):
        ts = torch.randint(0, sched.config.num_train_timesteps,
                           (batch.shape[0],), device="cuda").long()
        noise = torch.randn_like(lat)
        noisy = sched.add_noise(lat, noise, ts)
        if getattr(sched.config, "prediction_type", "epsilon") == "v_prediction":
            target = sched.get_velocity(lat, noise, ts)
        else:
            target = noise
        try:
            pred = pipe.transformer(noisy, ts,
                                    encoder_hidden_states=prompt_embeds)[0]
        except Exception as e:
            return False, f"forward-mismatch on {family}: {e}"
        loss = F.mse_loss(pred.float(), target.float())
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(pipe.transformer.parameters(), 1.0)
        opt.step()
        done += 1
        lval = float(loss.detach().cpu())
    secs = time.time() - t0
    lval = round(lval, 4)
    adir = os.path.join(outdir, "lora")
    os.makedirs(adir, exist_ok=True)
    try:
        pipe.transformer.save_pretrained(adir)
    except Exception as e:
        return False, f"lora-save-failed: {e}"
    return True, {"steps": done, "final_loss": lval,
                  "train_sec": round(secs, 1), "adapter_dir": adir}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--family", default="ltx", choices=FAMILIES)
    ap.add_argument("--tier", default="sfw", choices=["sfw", "nsfw"])
    ap.add_argument("--soma", default="")
    ap.add_argument("--prompt", default="a woman dancing softly, "
                    "weight shifting, arms swaying")
    ap.add_argument("--pairs", default="./pairs")
    ap.add_argument("--steps", type=int, default=200)
    ap.add_argument("--outdir", default="agent_out")
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    full_prompt, soma_kb = read_encoder(a.soma, a.prompt)
    ok, detail = train_lora(a.family, a.tier, a.pairs, full_prompt,
                            a.steps, a.outdir)
    samples = sorted(glob.glob(os.path.join(a.outdir, "frames", "*.png")))
    sharp = [sharpness(p) for p in samples[:4]]
    report = {
        "family": a.family, "tier": a.tier, "prompt": full_prompt[:200],
        "soma_kb": round(soma_kb, 1), "trained": ok,
        "detail": detail,
        "sample_sharpness": sharp,
        "status": "TRAINED" if ok else "PARKED-needs-gpu",
    }
    nxt = {"need": ("more-pairs" if ok else "gpu-or-colab"),
           "family": a.family, "tier": a.tier,
           "ask": ("paste agent_report.json back; app prepares more "
                   ".soma pairs" if ok else
                   "run this script where CUDA+peft exist, then paste "
                   "agent_report.json back")}
    json.dump(report, open(os.path.join(a.outdir, "agent_report.json"),
                           "w"), indent=1)
    json.dump(nxt, open(os.path.join(a.outdir, "next_task.json"),
                        "w"), indent=1)
    print(json.dumps(report, indent=1))
    print("NEXT: " + json.dumps(nxt))


if __name__ == "__main__":
    main()
