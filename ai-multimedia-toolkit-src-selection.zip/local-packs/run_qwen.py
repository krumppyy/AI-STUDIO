"""Qwen-Image-Edit human i2i. Apache 2.0 weights."""
import argparse, json, time

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(\"--prompt\", default=\"same person, warm cinematic light\")
    ap.add_argument(\"--image\", default=\"input.png\")
    ap.add_argument(\"--steps\", type=int, default=8)
    ap.add_argument(\"--height\", type=int, default=768)
    ap.add_argument(\"--precision\", default=\"bf16\")
    ap.add_argument(\"--cpu\", action=\"store_true\")
    ap.add_argument(\"--compile\", action=\"store_true\")
    ap.add_argument(\"--lowvram\", action=\"store_true\")
    ap.add_argument(\"--quant\", default=\"\")
    a = ap.parse_args()
    t0 = time.time()
    from diffusers import QwenImageEditPipeline
    import torch
    dt = torch.float32 if a.precision == \"fp32\" else torch.bfloat16
    pipe = QwenImageEditPipeline.from_pretrained(\"Qwen/Qwen-Image-Edit\", torch_dtype=dt)
    if a.cpu or a.lowvram:
        pipe.enable_sequential_cpu_offload()
    else:
        pipe.enable_model_cpu_offload()
    if a.compile:
        try:
            pipe.transformer = torch.compile(pipe.transformer, mode=\"reduce-overhead\")
        except Exception as e:
            print(\"compile skipped:\", e)
    load_sec = time.time() - t0
    from PIL import Image
    img = Image.open(a.image).convert(\"RGB\")
    i0 = time.time()
    out = pipe(image=img, prompt=a.prompt,
               num_inference_steps=a.steps).images[0]
    infer_sec = time.time() - i0
    out.save(\"qwen_out.png\")
    timing = {\"family\": \"qwen\", \"steps\": a.steps, \"height\": a.height,
              \"load_sec\": round(load_sec, 1), \"infer_sec\": round(infer_sec, 1),
              \"total_sec\": round(time.time() - t0, 1),
              \"compile\": a.compile, \"cpu\": a.cpu, \"quant\": a.quant}
    json.dump(timing, open(\"timing.json\", \"w\"), indent=1)
    print(json.dumps(timing, indent=1))

if __name__ == \"__main__\":
    main()
