"""HunyuanVideo I2V 13B human i2v. Tencent community license (conditional)."""
import argparse, json, time

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(\"--prompt\", default=\"a person standing, gentle idle motion\")
    ap.add_argument(\"--start\", default=\"start.png\")
    ap.add_argument(\"--steps\", type=int, default=6)
    ap.add_argument(\"--frames\", type=int, default=97)
    ap.add_argument(\"--height\", type=int, default=480)
    ap.add_argument(\"--precision\", default=\"bf16\")
    ap.add_argument(\"--cpu\", action=\"store_true\")
    ap.add_argument(\"--compile\", action=\"store_true\")
    ap.add_argument(\"--lowvram\", action=\"store_true\")
    ap.add_argument(\"--quant\", default=\"int8\")
    a = ap.parse_args()
    t0 = time.time()
    from diffusers import HunyuanVideoImageToVideoPipeline
    import torch
    dt = torch.float32 if a.precision == \"fp32\" else torch.bfloat16
    kw = {}
    if a.quant in (\"int8\", \"fp8\"):
        try:
            from diffusers import QuantizedHunyuanVideoTransformerConfig
            kw[\"transformer\"] = QuantizedHunyuanVideoTransformerConfig()
        except Exception as e:
            print(\"quant skipped:\", e)
    pipe = HunyuanVideoImageToVideoPipeline.from_pretrained(
        \"hunyuanvideo-community/HunyuanVideo-1.5\", torch_dtype=dt, **kw)
    pipe.enable_sequential_cpu_offload()
    pipe.vae.enable_tiling()
    if a.compile:
        try:
            pipe.transformer = torch.compile(pipe.transformer, mode=\"reduce-overhead\")
        except Exception as e:
            print(\"compile skipped:\", e)
    load_sec = time.time() - t0
    from PIL import Image
    start = Image.open(a.start).convert(\"RGB\")
    n = max(5, min(129, a.frames))
    n = round((n - 1) / 4) * 4 + 1
    i0 = time.time()
    out = pipe(image=start, prompt=a.prompt, num_frames=n,
               height=a.height, width=a.height * 16 // 9,
               num_inference_steps=a.steps, guidance_scale=6.0).frames[0]
    infer_sec = time.time() - i0
    out[0].save(\"hunyuan_start.png\")
    timing = {\"family\": \"hunyuan\", \"steps\": a.steps, \"frames\": n,
              \"height\": a.height, \"load_sec\": round(load_sec, 1),
              \"infer_sec\": round(infer_sec, 1),
              \"total_sec\": round(time.time() - t0, 1),
              \"compile\": a.compile, \"cpu\": True, \"quant\": a.quant}
    json.dump(timing, open(\"timing.json\", \"w\"), indent=1)
    print(json.dumps(timing, indent=1))

if __name__ == \"__main__\":
    main()
