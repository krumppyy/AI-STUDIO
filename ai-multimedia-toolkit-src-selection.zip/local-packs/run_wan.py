"""Wan Fun InP 1.3B human i2v + .soma roundtrip. Apache 2.0 weights."""
import argparse, json, time

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(\"--prompt\", default=\"a person standing, gentle idle motion\")
    ap.add_argument(\"--start\", default=\"start.png\")
    ap.add_argument(\"--steps\", type=int, default=6)
    ap.add_argument(\"--frames\", type=int, default=33)
    ap.add_argument(\"--height\", type=int, default=480)
    ap.add_argument(\"--precision\", default=\"bf16\")
    ap.add_argument(\"--cpu\", action=\"store_true\")
    ap.add_argument(\"--compile\", action=\"store_true\")
    ap.add_argument(\"--lowvram\", action=\"store_true\")
    ap.add_argument(\"--quant\", default=\"\")
    ap.add_argument(\"--out\", default=\"wan_out.mp4\")
    a = ap.parse_args()
    t0 = time.time()
    from diffusers import WanImageToVideoPipeline
    import torch
    dt = torch.float32 if a.precision == \"fp32\" else torch.bfloat16
    pipe = WanImageToVideoPipeline.from_pretrained(\"Wan-AI/Wan2.1-Fun-1.3B-InP\", torch_dtype=dt)
    if a.cpu or a.lowvram:
        pipe.enable_sequential_cpu_offload()
    else:
        pipe.enable_model_cpu_offload()
    pipe.vae.enable_tiling()
    if a.compile:
        try:
            pipe.transformer = torch.compile(pipe.transformer, mode=\"reduce-overhead\")
        except Exception as e:
            print(\"compile skipped:\", e)
    load_sec = time.time() - t0
    from PIL import Image
    start = Image.open(a.start).convert(\"RGB\")
    i0 = time.time()
    out = pipe(image=start, prompt=a.prompt, num_frames=a.frames,
               height=a.height, width=a.height * 16 // 9,
               num_inference_steps=a.steps).frames[0]
    infer_sec = time.time() - i0
    out[0].save(\"wan_start.png\")
    timing = {\"family\": \"wan\", \"steps\": a.steps, \"frames\": a.frames,
              \"height\": a.height, \"load_sec\": round(load_sec, 1),
              \"infer_sec\": round(infer_sec, 1),
              \"total_sec\": round(time.time() - t0, 1),
              \"compile\": a.compile, \"cpu\": a.cpu, \"quant\": a.quant}
    json.dump(timing, open(\"timing.json\", \"w\"), indent=1)
    print(json.dumps(timing, indent=1))

if __name__ == \"__main__\":
    main()
